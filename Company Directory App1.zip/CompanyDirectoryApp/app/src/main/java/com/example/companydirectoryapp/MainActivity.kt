package com.example.companydirectoryapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.companydirectoryapp.ui.theme.CompanyDirectoryAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompanyDirectoryAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    CompanyDirectoryScreen()
                }
            }
        }
    }
}

data class Company(
    val name: String,
    val category: String,
    val phone: String,
    val email: String,
    val tags: List<String>,
    val website: String? = null
)

val companies = listOf(
    Company("Safaricom", "Telecommunications", "1234567890", "support@telecom.com", listOf("Redirects Call"), "https://www.safaricom.co.ke"),
    Company("Starlink", "Telecommunications", "9876543210", "info@speednet.com", listOf("Gmail to Gmail"), "https://www.starlink.com"),
    Company("Panari Hotel", "Hotels", "1112223333", "contact@hotelbliss.com", listOf("Redirects Call"), "https://www.panarihotel.com"),
    Company("Tow King", "Tow Truck Services", "4445556666", "help@towking.com", listOf(), null),
    Company("Hilton Hotel", "Hotels", "7778889999", "stay@luxury.com", listOf("Gmail to Gmail"), "https://www.hilton.com"),
    Company("Strathmore University", "University", "0700123456", "info@strathmore.edu", listOf("Education"), "https://www.strathmore.edu"),
    Company("Red Cross Ambulance", "Ambulance Services", "1199", "rescue@redcross.org", listOf("Emergency"), "https://www.redcross.or.ke"),
    Company("Aqua Drop Delivery", "Water Delivery Services", "0700999888", "order@aquadrop.co.ke", listOf("Utility"), null),
    Company("Gogas Delivery", "Gas Delivery Services", "0711223344", "support@gogas.co.ke", listOf("Home Delivery"), "https://gogas.co.ke"),
    Company("Go Clean", "Laundry Services", "0766445532", "clean@laundry.co.ke", listOf("Utilities"), null)
)

@Composable
fun CompanyDirectoryScreen() {
    var searchQuery by remember { mutableStateOf(TextFieldValue("")) }
    val context = LocalContext.current

    // Show all companies if search is blank; otherwise filter
    val filtered = companies.filter {
        it.name.contains(searchQuery.text, ignoreCase = true) ||
                it.category.contains(searchQuery.text, ignoreCase = true)
    }.groupBy { it.category }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(48.dp))

        // App Title
        Text(
            text = "Service X",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary,
            fontSize = 30.sp,
            modifier = Modifier.padding(bottom = 4.dp)
        )

        // Subheading
        Text(
            text = "What services are you looking for?",
            fontSize = 18.sp,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // Search box
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Search services") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        // No results message
        if (searchQuery.text.isNotBlank() && filtered.isEmpty()) {
            Text(
                text = "No results found.",
                fontSize = 16.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 16.dp)
            )
        }

        // Display results
        if (filtered.isNotEmpty()) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                filtered.forEach { (category, companies) ->
                    item {
                        Text(
                            text = category,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                    items(companies) { company ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(text = company.name, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = "Phone: ${company.phone}",
                                    modifier = Modifier.clickable {
                                        val intent = Intent(Intent.ACTION_DIAL).apply {
                                            data = Uri.parse("tel:${company.phone}")
                                        }
                                        context.startActivity(intent)
                                    }
                                )

                                Text(
                                    text = "Email: ${company.email}",
                                    modifier = Modifier.clickable {
                                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                                            data = Uri.parse("mailto:${company.email}")
                                        }
                                        context.startActivity(intent)
                                    }
                                )

                                if (!company.website.isNullOrBlank()) {
                                    Text(
                                        text = "Website: ${company.website}",
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 14.sp,
                                        modifier = Modifier
                                            .padding(top = 4.dp)
                                            .clickable {
                                                val intent = Intent(Intent.ACTION_VIEW).apply {
                                                    data = Uri.parse(company.website)
                                                }
                                                context.startActivity(intent)
                                            }
                                    )
                                }

                                if (company.tags.isNotEmpty()) {
                                    Text(
                                        text = "Tags: ${company.tags.joinToString()}",
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}